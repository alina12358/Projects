pollutantmean <- function(direct,pollut,id=1:332){
  num = 0
  tot = 0
  path = getwd()
  for(n in id){
    df = read(file.path(direct,paste(as.character(n),".csv",sep="")))
    vect= df[[pollut]][!is.na(df[[pollut]])]
    tot =sum(tot,vect)
    num =num+length(vect)
  }
  tot/num
}